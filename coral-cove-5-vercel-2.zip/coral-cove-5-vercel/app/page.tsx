'use client';

import { useState } from 'react';
import { CalendarDays, Wifi, Users, PawPrint, CigaretteOff, Ticket, MapPin, Phone, Mail, CheckCircle, Menu, X } from 'lucide-react';

const lodgeImages = [
  { label: 'Decking & entrance', src: '/images/lodge-exterior-decking.jpg' },
  { label: 'Lounge', src: '/images/lodge-lounge.jpg' },
  { label: 'Kitchen & dining', src: '/images/lodge-kitchen-dining.jpg' },
  { label: 'Dining area', src: '/images/lodge-dining.jpg' },
  { label: 'Master bedroom', src: '/images/lodge-master-bedroom.jpg' },
  { label: 'Twin bedroom', src: '/images/lodge-twin-bedroom.jpg' },
];

const prices = [
  ['June & July 2026', '£220', 'per night'],
  ['August 2026', '£270', 'per night'],
  ['September 2026', '£200', 'per night'],
];

const features = [
  'Regal Cranleigh lodge',
  'Sleeps 4 guests',
  '2 comfortable bedrooms',
  'Open-plan lounge, kitchen & dining',
  'Large decking area',
  'Free WiFi',
  'Entertainment passes included',
  'No pets and no smoking',
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f7f2ea] text-[#12251f]">
      <header className="fixed inset-x-0 top-0 z-50 bg-[#08231c]/95 text-white backdrop-blur shadow-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <a href="#home" className="leading-tight">
            <div className="font-serif text-2xl tracking-wide">Coral Cove 5</div>
            <div className="text-xs uppercase tracking-[0.22em] text-[#d6a34a]">Beverley Holiday Park, Devon</div>
          </a>
          <nav className="hidden items-center gap-7 text-sm font-semibold uppercase tracking-wide md:flex">
            <a href="#lodge" className="hover:text-[#d6a34a]">The Lodge</a>
            <a href="#gallery" className="hover:text-[#d6a34a]">Gallery</a>
            <a href="#prices" className="hover:text-[#d6a34a]">Prices</a>
            <a href="#park" className="hover:text-[#d6a34a]">The Park</a>
            <a href="#contact" className="hover:text-[#d6a34a]">Contact</a>
            <a href="#book" className="rounded-xl bg-[#c7943e] px-5 py-3 text-white shadow hover:bg-[#b38335]">Book Now</a>
          </nav>
          <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && (
          <div className="border-t border-white/10 px-5 pb-5 md:hidden">
            {['lodge', 'gallery', 'prices', 'park', 'contact', 'book'].map((item) => (
              <a key={item} href={`#${item}`} onClick={() => setMenuOpen(false)} className="block py-3 text-sm uppercase tracking-wide">
                {item === 'book' ? 'Book Now' : item}
              </a>
            ))}
          </div>
        )}
      </header>

      <section id="home" className="relative flex min-h-[760px] items-center overflow-hidden pt-24">
        <div className="absolute inset-0 bg-[url('/images/lodge-exterior-decking.jpg')] bg-cover bg-center" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#071c17]/90 via-[#071c17]/55 to-transparent" />
        <div className="relative mx-auto w-full max-w-7xl px-5 py-24 text-white">
          <p className="mb-4 text-sm font-bold uppercase tracking-[0.3em] text-[#d6a34a]">Beverley Holiday Park, Devon</p>
          <h1 className="max-w-3xl font-serif text-5xl leading-tight md:text-7xl">Coral Cove 5</h1>
          <p className="mt-4 max-w-2xl font-serif text-3xl italic text-[#e6c27b] md:text-5xl">Your luxury escape on Devon’s English Riviera</p>
          <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/90">A beautiful Regal Cranleigh lodge sleeping 4 guests, set on Beverley Holiday Park in Paignton. Relax, unwind and enjoy a stylish coastal break with free WiFi and entertainment passes included.</p>
          <div className="mt-9 flex flex-wrap gap-4">
            <a href="#book" className="rounded-xl bg-[#c7943e] px-7 py-4 font-bold uppercase tracking-wide shadow-xl hover:bg-[#b38335]">Book Your Stay</a>
            <a href="#gallery" className="rounded-xl border border-white/70 px-7 py-4 font-bold uppercase tracking-wide hover:bg-white hover:text-[#08231c]">View Gallery</a>
          </div>
        </div>
      </section>

      <section className="bg-white shadow-sm">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-5 py-6 md:grid-cols-5">
          <Info icon={<Users />} title="Sleeps 4" text="2 bedrooms" />
          <Info icon={<PawPrint />} title="No pets" text="Sorry, no pets" />
          <Info icon={<CigaretteOff />} title="No smoking" text="Inside the lodge" />
          <Info icon={<Wifi />} title="Free WiFi" text="Stay connected" />
          <Info icon={<Ticket />} title="Passes included" text="Entertainment access" />
        </div>
      </section>

      <main>
        <section id="lodge" className="mx-auto grid max-w-7xl gap-10 px-5 py-20 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <p className="mb-3 text-sm font-bold uppercase tracking-[0.25em] text-[#c7943e]">The Lodge</p>
            <h2 className="font-serif text-4xl md:text-5xl">A stylish Regal Cranleigh lodge made for relaxing</h2>
            <p className="mt-6 text-lg leading-relaxed text-slate-700">Coral Cove 5 has a warm boutique feel, with a spacious open-plan lounge, modern kitchen, elegant dining area and comfortable bedrooms. The large windows and French doors bring in plenty of light, opening out onto decking for relaxed mornings, sunny afternoons and peaceful evenings.</p>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {features.map((feature) => (
                <div key={feature} className="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm">
                  <CheckCircle className="h-5 w-5 text-[#c7943e]" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div id="prices" className="rounded-3xl bg-white p-6 shadow-xl">
            <h3 className="font-serif text-3xl">Prices & Availability</h3>
            <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200">
              {prices.map(([season, price, note]) => (
                <div key={season} className="grid grid-cols-[1fr_auto] border-b border-slate-200 p-4 last:border-b-0">
                  <span className="font-semibold">{season}</span>
                  <span><strong>{price}</strong> <span className="text-slate-500">{note}</span></span>
                </div>
              ))}
            </div>
            <div className="mt-6 space-y-3 text-sm text-slate-700">
              <p>Minimum 3 nights for weekend stays: Friday to Monday.</p>
              <p>Minimum 4 nights for midweek stays: Monday to Friday.</p>
            </div>
            <div id="book" className="mt-7 rounded-2xl border border-dashed border-[#c7943e] bg-[#fbf6ec] p-5">
              <div className="flex items-center gap-3 font-bold"><CalendarDays className="text-[#c7943e]" /> Booking calendar</div>
              <p className="mt-3 text-sm text-slate-700">Embed your Bookalet, Lodgify or Smoobu live booking calendar here. This will block booked dates, show seasonal pricing and send email confirmations.</p>
              <a href="tel:07930156855" className="mt-5 block rounded-xl bg-[#c7943e] px-5 py-4 text-center font-bold uppercase text-white shadow hover:bg-[#b38335]">Call to Book: 07930 156855</a>
            </div>
          </div>
        </section>

        <section id="gallery" className="bg-white py-20">
          <div className="mx-auto max-w-7xl px-5">
            <div className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <p className="mb-3 text-sm font-bold uppercase tracking-[0.25em] text-[#c7943e]">Gallery</p>
                <h2 className="font-serif text-4xl md:text-5xl">Take a look around</h2>
              </div>
              <p className="max-w-xl text-slate-700">Step inside Coral Cove 5 and view the open-plan living area, kitchen, dining space, bedrooms, bathroom and decking.</p>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {lodgeImages.map((image, index) => (
                <div key={image.label} className={`${index === 0 ? 'md:col-span-2 md:row-span-2' : ''} group overflow-hidden rounded-3xl bg-slate-200 shadow-lg`}>
                  <img src={image.src} alt={image.label} className="h-full min-h-[250px] w-full object-cover transition duration-500 group-hover:scale-105" />
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="park" className="mx-auto grid max-w-7xl gap-10 px-5 py-20 lg:grid-cols-2">
          <div className="rounded-3xl bg-[#08231c] p-8 text-white shadow-xl">
            <p className="mb-3 text-sm font-bold uppercase tracking-[0.25em] text-[#d6a34a]">Beverley Holiday Park</p>
            <h2 className="font-serif text-4xl">Paignton, Devon</h2>
            <p className="mt-5 leading-relaxed text-white/85">Set in the heart of Devon’s English Riviera, Beverley Holiday Park gives you easy access to Paignton, Goodrington, Torquay, Brixham, beaches, coastal walks, family attractions and the park facilities.</p>
          </div>
          <div className="rounded-3xl bg-white p-8 shadow-xl">
            <h3 className="font-serif text-3xl">Important information</h3>
            <div className="mt-6 space-y-4 text-slate-700">
              <p><strong>Check-in:</strong> from 3:00pm</p>
              <p><strong>Check-out:</strong> by 10:00am</p>
              <p><strong>Address:</strong> Beverley Holiday Park, Goodrington Road, Paignton, Devon, TQ4 7JE</p>
              <p><strong>Rules:</strong> no pets and no smoking inside the lodge.</p>
            </div>
          </div>
        </section>
      </main>

      <footer id="contact" className="bg-[#071c17] text-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 md:grid-cols-3">
          <div>
            <h3 className="font-serif text-2xl">Coral Cove 5</h3>
            <p className="mt-3 text-white/75">A luxury Regal Cranleigh lodge on Devon’s English Riviera.</p>
          </div>
          <div className="space-y-3">
            <p className="flex items-center gap-3"><Phone className="h-5 w-5 text-[#d6a34a]" /> 07930 156855</p>
            <p className="flex items-center gap-3"><Mail className="h-5 w-5 text-[#d6a34a]" /> beverleyparkcaravans@gmail.com</p>
            <p className="flex items-center gap-3"><MapPin className="h-5 w-5 text-[#d6a34a]" /> Paignton, Devon TQ4 7JE</p>
          </div>
          <div>
            <a href="#book" className="inline-block rounded-xl bg-[#c7943e] px-7 py-4 font-bold uppercase tracking-wide text-white shadow hover:bg-[#b38335]">Book Now</a>
          </div>
        </div>
        <div className="border-t border-white/10 py-5 text-center text-sm text-white/60">© 2026 Coral Cove 5, Beverley Holiday Park. All rights reserved.</div>
      </footer>
    </div>
  );
}

function Info({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="text-[#08231c]">{icon}</div>
      <div>
        <div className="text-sm font-bold uppercase">{title}</div>
        <div className="text-sm text-slate-600">{text}</div>
      </div>
    </div>
  );
}
