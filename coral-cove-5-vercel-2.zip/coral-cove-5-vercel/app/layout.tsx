import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Coral Cove 5 | Beverley Holiday Park Devon',
  description: 'Luxury Regal Cranleigh holiday lodge at Beverley Holiday Park, Paignton, Devon. Sleeps 4, free WiFi, entertainment passes included.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
